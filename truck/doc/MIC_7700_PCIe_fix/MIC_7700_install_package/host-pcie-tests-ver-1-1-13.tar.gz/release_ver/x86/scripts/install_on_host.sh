#!
echo "Install on Host, $pwd $(realpath .)"

#
#	Copy Binary & Help files to /usr/local/bin
#	Files:
#+ dev_diagnostic-xxx-xxx-xxx tests board diagnostic all HW.
#+ dialog-menu tests menus tests user GUI mode.
#+ host-cli tests terminal mode no GUI and dialog-menu tests service.

# copy file from release_ver/x86/usr/local/bin(install path) to /usr/local/bin server host path.
echo "copy file from release_ver/x86/usr/local/bin(install path) to /usr/local/bin server host path"
echo "cp ./usr/local/bin/* /usr/local/bin"
ls ./usr/local/bin
cp ./usr/local/bin/* /usr/local/bin

# check exist log folder on host, if not create it. 
echo "mkdir -p /var/tmp/test-pci-conf/log /var/tmp/test-pci-conf/prev-logs"
mkdir -p /var/tmp/test-pci-conf/log /var/tmp/test-pci-conf/prev-logs

echo "Installation finished"